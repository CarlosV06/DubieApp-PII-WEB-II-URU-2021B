const express = require('express');
const app = express();
const via = require('path');
const hb = require('express-handlebars');
const methodOv = require('method-override');
const sesion = require('express-session');
const Passp = require('passport');
const Flash = require('connect-flash');
const Handlebars = require('handlebars');
const {allowInsecurePrototypeAccess} = require('@handlebars/allow-prototype-access');
//INICIALIZACIONES
require("./bd");
require('./config/passport');



//CONFIGURACIONES
app.set('port', process.env.PORT || 3000);
app.set('views', via.join(__dirname, 'views'))
app.engine('.hbs', hb({
	defaultLayout: 'main' ,
	layoutsDir: via.join(app.get('views'), 'layouts') ,
	partialsDir: via.join(app.get('views'), 'partials'),
	extname: '.hbs',
	handlebars: allowInsecurePrototypeAccess(Handlebars)
}));
app.set('view engine', '.hbs');
//MIDDLEWARES
app.use(express.urlencoded({extended: false}));
app.use(methodOv('_method'));
app.use(sesion({
    secret: 'unaappsecreta',
    resave: true,
    saveUninitialized: true
}));
app.use(Passp.initialize());
app.use(Passp.session());
app.use(express.json());
app.use(Flash());

//VARIABLES GLOBALES

app.use((req, res, next) =>{
    res.locals.Usuario = req.user || null;
    next();
});





//RUTAS
app.use(require('./routes/index'));
app.use(require('./routes/Artistas'));
app.use(require('./routes/ListasReproduccion'));
app.use(require('./routes/Usuario'));
app.use(require('./routes/canciones'));




//ARCHIVOS ESTÁTICOS
app.use(express.static(via.join(__dirname, 'public')));

//EL SERVIDOR ESTÁ ESCUCHANDO
app.listen(app.get('port'), () =>{
    console.log("El servidor está corriendo en el puerto: "+app.get('port'));
});
