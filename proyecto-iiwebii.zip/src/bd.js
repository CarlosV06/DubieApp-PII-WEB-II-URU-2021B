const Mongo = require('mongoose');

const url = "mongodb+srv://Admin:carlos151201@clusterwebii.d35p0.mongodb.net/PIIWEBII?retryWrites=true&w=majority";


Mongo.connect(url, {
    useCreateIndex: true,
    useUnifiedTopology: true,
    useNewUrlParser: true,
    useFindAndModify: false
}).then(db => console.log("Conexión establecida exitosamente.")).catch(err => console.error(err));


