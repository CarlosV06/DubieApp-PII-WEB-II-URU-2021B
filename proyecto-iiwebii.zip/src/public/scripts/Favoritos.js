const Boton = document.getElementById("Fav");

const VerFavoritos = (e) =>{
   
    fetch('/Listas/VerFavoritos', {
        method: 'GET'
    }).then(res =>{
        return res.json();
    }).then(res =>{
        console.log(res.Fav);
        let Padre = document.getElementById("Datos");
        Padre.innerHTML = "";

        
        let NombreLista = document.createElement('h1');
        NombreLista.innerText = "Favoritos";
        Padre.appendChild(NombreLista);
        for (i = 0; i<res.Fav.ListasReproduccionFavoritos.length; i++){
            
                let cont = document.createElement('div');
                cont.style.width = 'fit-content';
                
                let cancion = document.createElement('p');
                let canciona = document.createElement('p');
                let cancional = document.createElement('p');
                let cancionlan = document.createElement('p');
                let canciongen = document.createElement('p');
                cancion.innerText = res.Fav.ListasReproduccionFavoritos[i].NombreCancion;
                canciona.innerText = res.Fav.ListasReproduccionFavoritos[i].ArtistaC.Nombre;
                cancional.innerText = res.Fav.ListasReproduccionFavoritos[i].Album;
                cancionlan.innerText = res.Fav.ListasReproduccionFavoritos[i].Lanzamiento;
                canciongen.innerText = res.Fav.ListasReproduccionFavoritos[i].Genero;
                cont.appendChild(cancion);
                cont.appendChild(canciona);
                cont.appendChild(cancional);
                cont.appendChild(cancionlan);
                cont.appendChild(canciongen);

                Padre.appendChild(cont);
            
        }

        


    })
}

Boton.onclick = VerFavoritos;