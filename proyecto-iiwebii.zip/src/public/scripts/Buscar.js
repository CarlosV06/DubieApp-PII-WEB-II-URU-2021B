const BotonBuscar = document.getElementById("Busqueda");


const BuscarC = (e) =>{
    
    e.preventDefault();
    const dato = document.getElementById("Dato").value;
    alert('Se procederá a buscar...'+dato);
    fetch('/Canciones/Buscar/'+dato, {
        method: 'GET'
    }).then(res =>{
        return res.json();
    }).then(res =>{
       
        const e = window.event;
        let Padre = document.getElementById('Datos');
        Padre.innerHTML = "";

        for(i = 0; i < res.ResultadosB.length; i++){
            //alert(res.ResultadosB[i].ArtistaC.Nombre);
            let info = document.createElement('div');
            info.id = i;
            info.style.width = "100%";
            info.style.justifyContent = "center";
            info.style.alignItems = "center";
            info.style.display = "flex";
            info.style.flexDirection = "row";
            info.style.float = "left";

            let Titulo = document.createElement('p');
            let AFav = document.createElement('button');
            let Reproducir = document.createElement('button');
            let AListaR = document.createElement('button');
            let Artista = document.createElement('p');
            let Album = document.createElement('p');
            let Lanzamiento = document.createElement('p');
            let Genero = document.createElement('p');

            Titulo.innerText = "Titulo: "+res.ResultadosB[i].NombreCancion+"|          ";
            Artista.innerText = "Artista: "+res.ResultadosB[i].ArtistaC.Nombre;
            Artista.id = res.ResultadosB[i].ArtistaC._id;
            Artista.style.color = "blue";
            Album.innerText = "|          "+"Album: "+res.ResultadosB[i].Album;
            Lanzamiento.innerText = "|          "+"Lanzamiento: "+res.ResultadosB[i].Lanzamiento;
            Genero.innerText = "|   "+"Genero: "+res.ResultadosB[i].Genero+"|          ";
            AFav.innerText = "A Favoritos";
            AFav.id = res.ResultadosB[i]._id;
            AFav.onclick = (e) =>{
                let idCancion = e.target.id;
                alert('Se va a agregar la canción con id: '+idCancion+'a FAVORITOS');
                fetch('/Canciones/AgregarAFavoritos/'+idCancion, {
                    method: 'POST'
                }).then(res =>{
                    return res.json();
                }).then(res =>{
                    alert('Se ha agregado la canción a la lista de reproducción FAVORITOS. Puede visualizarla dando click al botón de la lista específica');

                });
            }
            AListaR.innerText = "A una Lista";
            AListaR.id = res.ResultadosB[i]._id;
            AListaR.onclick = (e) =>{
                alert('Agregando a la lista...');
            }
            Reproducir.innerText = "Reproducir";
            Reproducir.onclick = (e) =>{
                alert('Reproduciendo...');
            }

            info.appendChild(Titulo);
            info.appendChild(Artista);
            info.appendChild(Album);
            info.appendChild(Lanzamiento);
            info.appendChild(Genero);
            info.appendChild(AFav);
            info.appendChild(AListaR);
            info.appendChild(Reproducir);

            Padre.appendChild(info);
        }

    

    });

}

BotonBuscar.onclick = BuscarC;