//alert('Se está ejecutando un script.');

const MostrarListar = (e) =>{
    fetch('/Listas/MostrarListas').then(respuesta =>{
    return respuesta.json();
    }).then(respuesta =>{
        
        const Padre = document.getElementById("RecipienteListas");

        for(i = 0; i < respuesta.NombreLR.length; i++){
            
            const LR = document.createElement('a');
            LR.id = respuesta.NombreLR[i]._id;
            LR.innerText = `${respuesta.NombreLR[i].NombreListaR}`;
            LR.onclick = (e) =>{
                let idLista = e.target.id;
               
                fetch('/Listas/VerListaR/'+idLista, {
                    method: 'GET'
                }).then(res =>{
                    return res.json();
                }).then(res =>{
                    let Padre = document.getElementById("Datos");
                    Padre.innerHTML = "";
                    

                    let NombreLista = document.createElement('h1');
                    NombreLista.innerText = res.DatoLista.NombreListaR;
                    
                    Padre.appendChild(NombreLista);


                   // for (i = 0; i < res.DatoLista.CancionesLR.length; i++){
                     //   let cancion = document.createElement('p');
                       // cancion.innerText = res.DatoLista.CancionesLR[i].Album;
                    //}



                });
            };

            Padre.appendChild(LR);
           
            
        }
        

    });
}

window.onload = MostrarListar;