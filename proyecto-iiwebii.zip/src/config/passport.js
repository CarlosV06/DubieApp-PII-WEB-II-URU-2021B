const Passp = require('passport');
const localStrategy = require('passport-local').Strategy;

const Usuarios = require('../models/NuevoUsuario');


Passp.use(new localStrategy({
    usernameField: 'email', passwordField: 'pass'}, async (email, pass, listo) => {
        console.log("Fuciona la función.");
        const Usuario = await Usuarios.findOne({email: email});
        if (!Usuario){
            console.log('Usuario no encontrado.');
            return listo(null, false, {mensaje: 'Usuario no encontrado.'});
        }else{
            const Coincidencia = await Usuario.matchPassword(pass);
            console.log(Coincidencia);

            if(Coincidencia){
                return listo(null, Usuario);
            }else {
                return listo(null, false, {mensaje: 'Contraseña incorrecta.'});
            }
        }
}));


Passp.serializeUser((Usuario, listo) =>{
    listo(null, Usuario.id);
});

Passp.deserializeUser((id, listo) =>{
    Usuarios.findById(id, (err, Usuario) =>{
        listo(err, Usuario);
    });
});