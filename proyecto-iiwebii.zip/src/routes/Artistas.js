const enrutador = require('express').Router();
const {isAuthenticated} = require('../helpers/auth');
const Canciones = require('../models/Cancion');
const ListaR = require('../models/ListaReproduccion');
const Artista = require('../models/Artista')
const Usuarios = require('../models/NuevoUsuario');

enrutador.get('/Artistas/NuevoArtista', isAuthenticated, (req, res) =>{
    res.render('dubieapp/AgregarArtista');
});

enrutador.post('/Artistas/CrearArtista', async (req, res) =>{
    const {nameartista} = req.body;

    if(!nameartista){
        console.log("Por favor, ingrese un nombre para el artista.");
        res.render('dubieapp/AgregarArtista');
    }

    const NuevoArtista = new Artista({Nombre: nameartista});
    console.log(NuevoArtista);
    await NuevoArtista.save();
     
    res.redirect('/Artista/ArtistaCreado');

});

enrutador.get('/Artista/ArtistaCreado', (req, res) =>{
    res.render('dubieapp/AgregadoArtis');
});

module.exports = enrutador;