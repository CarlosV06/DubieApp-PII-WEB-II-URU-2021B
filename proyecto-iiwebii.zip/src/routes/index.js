const enrutador = require('express').Router();
const {isAuthenticated} = require('../helpers/auth');


enrutador.get('/', (req, res) => {
    res.render('Index');
})

enrutador.get('/About', (req, res) =>{
    res.render('About');
})

enrutador.get('/Inicio', isAuthenticated , (req, res) => {
    const RolUsuario = req.user.rol;


    if(RolUsuario == "Usuario"){
        res.render('dubieapp/dubieappusuarios'); 
    }else{
        res.render('dubieapp/dubieinicio');
    }
    
    
    //res.send('ok');

});


enrutador.get('/Nuevo', (req, res) =>{
    res.render('dubieapp/Agregar');
})



module.exports = enrutador;
