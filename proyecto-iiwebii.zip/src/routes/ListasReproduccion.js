const enrutador = require('express').Router();
const {isAuthenticated} = require('../helpers/auth');
const Canciones = require('../models/Cancion');
const ListaR = require('../models/ListaReproduccion');
const Artista = require('../models/Artista')
const Usuarios = require('../models/NuevoUsuario');

enrutador.get('/Listas/CrearLista',isAuthenticated, (req, res) =>{
    res.render('dubieapp/NuevaLR');
});

enrutador.post('/Listas/NuevaLista/:idU', isAuthenticated, async (req, res) =>{
    let idUsuario = req.params.idU;
    const {namep} = req.body;
    
    if(!namep){
        console.log('Por favor ingrese un nombre para su lista de reproducción.');
        res.render('dubieapp/NuevaLista');
    }

    const NuevaListaR = new ListaR({NombreListaR: namep, propietarioLista: `${idUsuario}`});
    console.log(NuevaListaR);



    await NuevaListaR.save();

    res.redirect('/Inicio');
});

enrutador.get('/Listas/MostrarListas', async (req, res) =>{

    const Listas = await ListaR.find({propietarioLista: req.user.id}).populate("CancionesLR");
   

    //const ArtistaR = await Artista.findOne({Nombre: 'Nacho'})
    //.populate("CancionesArtista");
    //console.log(ArtistaR);

    res.status(200).json({NombreLR: Listas});

});

enrutador.get('/Listas/VerListaR/:idLista', async (req, res) =>{
    const IDLista = req.params.idLista;
    console.log('el id que llego es: '+IDLista);
    const ListadeReproduccion = await ListaR.findById({_id: IDLista}).populate("CancionesLR");
    
    console.log(ListadeReproduccion);
       res.status(200).json({
           DatoLista: ListadeReproduccion,
       });
    
});

enrutador.get('/Listas/VerFavoritos', async (req, res) =>{
    const Favoritos = await Usuarios.findById({_id: req.user.id}).populate({path: "ListasReproduccionFavoritos"
    ,populate: {
        path: "ArtistaC"
    }
});
    console.log(Favoritos);

    res.status(200).json({
        Fav: Favoritos
    });
});


module.exports = enrutador;