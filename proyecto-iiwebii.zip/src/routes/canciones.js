const enrutador = require('express').Router();
const {isAuthenticated} = require('../helpers/auth');
const Canciones = require('../models/Cancion');
const ListaR = require('../models/ListaReproduccion');
const Artista = require('../models/Artista')
const Usuarios = require('../models/NuevoUsuario');

enrutador.get('/Canciones/AgregarCancion', (req, res) =>{
    res.render('dubieapp/AgregarCancion');

});

enrutador.post('/Canciones/NuevaCancion', async (req, res) =>{
    const {namecancion, nameartista, album, lanzamiento, genero, rutac} = req.body;

    //SE OBTIENE LA INFORMACIÓN DEL ARTISTA
    const BuscarArtista = await Artista.findOne({Nombre: nameartista});

    if(!BuscarArtista){
        console.log('No se ha encontrado ningún artista con ese nombre.');
    }

    const IDArtista = BuscarArtista.id;

    const NuevaCancion = new Canciones({
        NombreCancion: namecancion,
        ArtistaC: IDArtista,
        Album: album,
        Lanzamiento: lanzamiento,
        Genero: genero,
        Ruta: rutac
    });

    console.log(NuevaCancion);
    

    await NuevaCancion.save();

    await Artista.findByIdAndUpdate(IDArtista, {
        "$set":{ Nombre: nameartista }, 
        "$push":{ CancionesArtista: NuevaCancion.id }
    });

    res.redirect('/Canciones/CancionAgr');
//

});

enrutador.get('/Canciones/CancionAgr', (req, res) =>{
    res.render('dubieapp/CancionAgregada');
});

enrutador.get('/Canciones/Buscar/:dato',async (req, res) =>{
    const resultadob = req.params.dato;
    const CancionesB = await Canciones.find({NombreCancion: {$regex: resultadob, $options: "$i"}})
    .populate("ArtistaC");

    
    console.log(CancionesB); 

    res.status(200).json({
        ResultadosB : CancionesB
    });
});

enrutador.post('/Canciones/AgregarAFavoritos/:idCancion', async (req, res) =>{
    console.log(req.params.idCancion);
    const Resultado = await Usuarios.findByIdAndUpdate(req.user.id, {
        "$push": {ListasReproduccionFavoritos: req.params.idCancion}
    });
    console.log(Resultado);
});

module.exports = enrutador;