const enrutador = require('express').Router();

const ListaR = require('../models/ListaReproduccion');

const NuevoU = require('../models/NuevoUsuario');
const Passp = require('passport');




enrutador.get('/usuarios/IniciarSesion', (req, res) =>{
    res.render('usuarios/iniciosesion');
})

enrutador.get('/usuarios/Registro', (req, res) =>{
    res.render('usuarios/registro');
})



enrutador.post('/usuarios/RegistroUsuario', async (req, res) =>{
    const {nombre, apellido, email, pass, cpass} = req.body;
    //PARA DETERMINAR ALGÚN ERROR EN LA TOMA DE LA DATA:
    const errores = [];
    
    if(!nombre){
        errores.push({text: 'Por favor ingrese un nombre.'});
    }

    if(!apellido){
        errores.push({text: 'Por favor ingrese un apellido.'});
    }

    if(!email){
        errores.push({text: 'Por favor ingrese un email.'});
    }

    if(pass != cpass){
        console.log('Las contraseñas no coinciden.');
        errores.push({text: 'Las contraseñas no coinciden.'});
    }

    if(errores.length > 0){
        console.log(req.body);
        res.render('usuarios/registro', {
            errores,
            nombre,
            apellido,
            email,
            pass
        })
    }else{
        //CREAMOS EL USUARIO
        let rol = "";
        //VALIDACIÓN DEL TIPO DE USUARIO 
        const tipoU = email.split('@');
        console.log(tipoU);

        if(tipoU[1] == "admindubie.com"){
            console.log('El usuario es administrador');
            rol = "Administrador"; 
        
        }else{
            console.log('El usuario no es un administrador');
            rol = "Usuario";
        }
        
       

      const NuevoUsuario =  new NuevoU({nombre, apellido, email, pass, rol});
        
      NuevoUsuario.pass = await NuevoUsuario.encryptPassword(pass);


      

       await NuevoUsuario.save();
      res.redirect('/');
    }
})

enrutador.post('/usuarios/InicioS', Passp.authenticate('local', {
    successRedirect: '/Inicio',
    failureRedirect: '/usuarios/Registro'
}) );


module.exports = enrutador;