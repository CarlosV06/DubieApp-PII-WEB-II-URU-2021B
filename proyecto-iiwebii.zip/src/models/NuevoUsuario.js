const Mongoose = require('mongoose');
const { Schema } = Mongoose;
const Encriptar = require('bcryptjs');
//DEFINIMOS LOS USUARIOS

const UsuarioS = new Schema({
    nombre: {type: String, required: true},
    apellido: {type: String, required: true},
    email: {type: String, required: true, unique: true},
    pass: {type: String, required: true},
    rol: {type: String, required: true},
    ListasReproduccionFavoritos: [{type: Mongoose.Schema.Types.ObjectId, ref: 'Canciones'}]
});


//ENCRIPTAR CONTRASEÑAS

UsuarioS.methods.encryptPassword = async (pass) =>{
    const Sal = await Encriptar.genSalt(10);
    const ContraseñaCifrada = Encriptar.hash(pass, Sal);
    return ContraseñaCifrada;
};
//VERIFICAR CONTRASEÑAS
UsuarioS.methods.matchPassword =  async function (pass){
return await Encriptar.compare(pass, this.pass)
};


module.exports = Mongoose.model('NUsuario', UsuarioS)


