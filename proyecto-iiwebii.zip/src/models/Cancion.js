const Mongoose = require('mongoose');
const { Schema } = Mongoose;


const Cancion = new Schema({
    NombreCancion: {type: String, required: true},
    ArtistaC: {type: Mongoose.Schema.Types.ObjectId, ref: 'Artista', required: true},
    Album: {type: String, required: true},
    Lanzamiento: {type: String, required: true},
    Genero: {type: String, required: true},
    Ruta: {type: String, required: true}
});

module.exports = Mongoose.model('Canciones', Cancion);



