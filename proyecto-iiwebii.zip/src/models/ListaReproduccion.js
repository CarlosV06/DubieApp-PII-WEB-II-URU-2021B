const Mongoose = require('mongoose');
const { Schema } = Mongoose;

//SE DEFINE EL ESQUEMA DE LAS LISTAS DE REPRODUCCIÓN


const ListaR = new Schema({
    NombreListaR: {type: String, required: true},

    propietarioLista: {type: Mongoose.Schema.Types.ObjectId, ref: 'NUsuario', required: true},

    CancionesLR: [{type: Mongoose.Schema.Types.ObjectId, ref: 'Canciones'}]
});


module.exports = Mongoose.model('ListaReproduccion', ListaR);


