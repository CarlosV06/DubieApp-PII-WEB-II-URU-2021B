
const Mongoose = require('mongoose');
const { Schema } = Mongoose;

//DEFINIR EL ESQUEMA DE UN ARTISTA
const Artista = new Schema({
    Nombre: {type: String, unique: true, required: true},
    CancionesArtista: [{type: Mongoose.Schema.Types.ObjectId, ref: 'Canciones'}]
});

module.exports = Mongoose.model('Artista', Artista);